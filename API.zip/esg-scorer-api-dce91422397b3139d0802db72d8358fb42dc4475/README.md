# ESG Scorer API

This is the Flask app that supports API endpoints for running and getting responses from ML models used in our ESG Scorer app (https://github.com/anhvungoc21/esg-scorer)
