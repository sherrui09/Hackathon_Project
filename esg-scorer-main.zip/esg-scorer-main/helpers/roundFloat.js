export default function roundFloat(float) {
  return float.toFixed(3);
}
